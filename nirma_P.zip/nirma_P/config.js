export const API_BASE_URL = 'https://api.example.com';
export const INVENTORY_ENDPOINT = '/inventory';
export const SPOILAGE_ENDPOINT = '/spoilage';

