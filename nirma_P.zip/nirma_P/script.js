import * as config from 'config';
import * as utils from 'utils';

document.addEventListener('DOMContentLoaded', async () => {
    // Initialize inventory table
    await populateInventoryTable();

    // Initialize spoilage chart
    await initializeSpoilageChart();

    // Add event listener to the add inventory form
    const addInventoryForm = document.getElementById('add-inventory-form');
    if (addInventoryForm) {
        addInventoryForm.addEventListener('submit', handleAddInventory);
    }
});

async function populateInventoryTable() {
    const inventoryData = await fetchInventoryData();
    const inventoryTableBody = document.getElementById('inventory-table-body');

    if (inventoryTableBody) {
        inventoryTableBody.innerHTML = ''; // Clear existing data
        inventoryData.forEach(item => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td class="border px-4 py-2">${item.name}</td>
                <td class="border px-4 py-2">${item.quantity}</td>
                <td class="border px-4 py-2">${item.unit}</td>
            `;
            inventoryTableBody.appendChild(row);
        });
    }
}


async function fetchInventoryData() {
    // Replace with actual API endpoint
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve([
                { name: 'Tomatoes', quantity: 50, unit: 'lbs' },
                { name: 'Lettuce', quantity: 20, unit: 'heads' },
                { name: 'Chicken', quantity: 30, unit: 'lbs' }
            ]);
        }, 500);
    });
}


async function initializeSpoilageChart() {
    const spoilageData = await fetchSpoilageData();
    const spoilageChartCanvas = document.getElementById('spoilage-chart');

    if (spoilageChartCanvas) {
        new Chart(spoilageChartCanvas, {
            type: 'bar',
            data: {
                labels: spoilageData.map(item => item.name),
                datasets: [{
                    label: 'Days Until Spoilage',
                    data: spoilageData.map(item => item.daysUntilSpoilage),
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
}

async function fetchSpoilageData() {
    // Replace with actual API endpoint
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve([
                { name: 'Tomatoes', daysUntilSpoilage: 2 },
                { name: 'Lettuce', daysUntilSpoilage: 3 },
                { name: 'Chicken', daysUntilSpoilage: 1 }
            ]);
        }, 500);
    });
}

async function handleAddInventory(event) {
    event.preventDefault(); // Prevent form submission

    const itemNameInput = document.getElementById('item-name');
    const itemQuantityInput = document.getElementById('item-quantity');
    const itemUnitInput = document.getElementById('item-unit');

    const itemName = itemNameInput.value;
    const itemQuantity = parseInt(itemQuantityInput.value);
    const itemUnit = itemUnitInput.value;

    if (itemName && !isNaN(itemQuantity) && itemUnit) {
        //optimistic update
        await addItemToInventory(itemName, itemQuantity, itemUnit);
        itemNameInput.value = '';
        itemQuantityInput.value = '';
        itemUnitInput.value = '';
    } else {
        alert('Please fill in all fields with valid data.');
    }
}

async function addItemToInventory(itemName, itemQuantity, itemUnit) {
   //faking it until you make it. In reality you'd call your backend here.
    const newItem = {name: itemName, quantity: itemQuantity, unit: itemUnit}
    const inventoryTableBody = document.getElementById('inventory-table-body');
    const row = document.createElement('tr');
    row.innerHTML = `
        <td class="border px-4 py-2">${newItem.name}</td>
        <td class="border px-4 py-2">${newItem.quantity}</td>
        <td class="border px-4 py-2">${newItem.unit}</td>
    `;
    inventoryTableBody.appendChild(row);
}

